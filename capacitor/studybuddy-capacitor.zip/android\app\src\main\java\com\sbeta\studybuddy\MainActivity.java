package com.sbeta.studybuddy;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
